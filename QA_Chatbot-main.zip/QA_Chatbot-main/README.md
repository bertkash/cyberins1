# QA_Chatbot
This app provides answers to questions based on the provided data.

## Getting Started
### Create Virtual Environment

```bash
python -m venv venv
source venv/bin/activate
```
### Install Packages

```bash
pip install -r requirements.txt
```

### Export OpenAI key
```bash
export OPENAI_API_KEY="sk-*******"
```

### Run Streamlit App
```bash
streamlit run app.py
```
