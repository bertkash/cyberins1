from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.docstore.document import Document
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
import os 
import constant

def generate_embeddings():
        file_path = os.path.join(os.getcwd(), "extracted_text.txt")

        with open(file_path, 'r') as file:
                extracted_text = file.read()

        text_splitter = RecursiveCharacterTextSplitter(chunk_size=2048, chunk_overlap=32,separators=["\n\n"])
        document = [Document(page_content=t) for t in text_splitter.split_text(extracted_text)]
        embeddings = HuggingFaceEmbeddings(model_name=constant.EMBEDDINGS_MODEL)
        db = Chroma.from_documents(document, embeddings, persist_directory=constant.PERSIST_DIRECTORY)
        