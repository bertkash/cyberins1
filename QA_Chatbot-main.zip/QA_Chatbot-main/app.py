import streamlit as st
import time
from llm_pipeline import pipeline 
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.prompts.prompt import PromptTemplate
import constant
import prompts
from llm_pipeline import pipeline



def main():
    st.markdown(
        """
        <style>
            .title-wrapper {
                position: fixed;
                top: 0;
                width: 100%;
                background-color: white;
                padding: 1rem;
                z-index: 1;
            }
            .content-wrapper {
                margin-top: 60px; /* Adjust margin-top based on the title's height */
                padding: 1rem;
            }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Title
    st.markdown(f"<div class='title-wrapper'><h1>{constant.TITLE}</h1></div>", unsafe_allow_html=True)

    # Content
    st.markdown("<div class='content-wrapper'>", unsafe_allow_html=True)

    CUSTOM_QUESTION_PROMPT = PromptTemplate.from_template(prompts.QA_PROMPT)
    chain = pipeline()
    embeddings = HuggingFaceEmbeddings(model_name='intfloat/e5-base-v2')
    db = Chroma(embedding_function=embeddings, persist_directory=constant.PERSIST_DIRECTORY)

    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display chat history
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # User input and assistant response
    if question := st.chat_input("Question"):
        # Display user message in chat message container
        with st.chat_message("user"):
            st.markdown(question)

        st.session_state.messages.append({"role": "user", "content": question})
        context = db.similarity_search(question, k=2)
        query = CUSTOM_QUESTION_PROMPT.format(question=question, context=context)

        # Display assistant response in chat message container
        with st.chat_message("assistant"):
            response = chain.run(query)
            st.markdown(response)
        st.session_state.messages.append({"role": "assistant", "content": response})

    st.markdown("</div>", unsafe_allow_html=True)

if __name__ == "__main__":
    main()
