from langchain.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
import constant
import os 
from generate_embeddings import generate_embeddings 

def pipeline():

    # os.environ["OPENAI_API_KEY"] = constant.API_KEY
    embeddings = HuggingFaceEmbeddings(model_name=constant.EMBEDDINGS_MODEL)
    if not os.path.exists(constant.PERSIST_DIRECTORY):
        generate_embeddings()
    db = Chroma(embedding_function=embeddings, persist_directory=constant.PERSIST_DIRECTORY)
    llm = ChatOpenAI(model_name=constant.OPEN_AI_MODEL)
    retrieval_chain = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db.as_retriever(search_kwargs={"k": 2}))
    return retrieval_chain