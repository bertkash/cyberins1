# OpenAI
OPEN_AI_MODEL = "gpt-3.5-turbo"


#title of app
TITLE = "Question Answer App"

# HuggingFace
EMBEDDINGS_MODEL = 'intfloat/e5-base-v2'
MODEL_KWARGS = {"device": "cpu"}

# Chroma
PERSIST_DIRECTORY = "embeddings"